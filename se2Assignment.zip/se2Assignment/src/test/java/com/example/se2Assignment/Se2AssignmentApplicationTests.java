package com.example.se2Assignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Se2AssignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
